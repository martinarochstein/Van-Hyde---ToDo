<template>
    
    <div class="container">

      <div class="containerButton">
        <button v-if="boton" id="mas" @click="mostrarForm">+</button>
      </div>

      <div>
        <h1>TO DO LIST</h1>
      </div>

      <div v-if="todos.length === 0">
        <p>No hay tareas para mostrar</p>
      </div>

      <table class="table" v-if="todos.length != 0">
        <tbody>
          <tr v-for="todo, index in todos" :key="index">
            <td>
              <button class='buttonEliminar' @click = "deleteTodo(index)">Eliminar</button>
            </td>
            <td :class="{completado: todo.completado}">
              <p class="tarea">{{todo.tarea}}</p>
            </td>
            <td>
              <input type="checkbox" v-model="todo.completado" @change="updateTodo(index,todo)">
            </td>
          </tr>
        </tbody>
      </table>

      <form v-if="form" @submit.prevent="addTodo" >
        <div>
          <h2>Agregar una tarea</h2>
          <div class="contenidoForm">
            <input type="text" v-model="nuevaTarea" placeholder="Tarea" required>
            <div class="checkboxCompletado">
              <label >Completado?  </label>
              <input class="checkbox" type="checkbox" v-model="nuevoCompletado">
            </div>
          </div>
          <button v-if="mostrarForm" class='buttonAgregar' type="submit">Agregar</button>
        </div>
        </form>

    </div>
</template> 

<script>
import axios from 'axios';

export default {
  data() {
    return {
      todos: [],
      nuevaTarea: "",
      nuevoCompletado:"",
      nueva: [],
      form: false,
      boton: true
    };
  },
  created() {
    this.getTodos();
  },
  methods: {

    getTodos() {
      const path = 'http://localhost:5000/api/todos'
      axios.get(path)
      .then(response =>{
        console.log(response.data.todos)
        this.todos = response.data.todos
      })
      .catch(error =>{
        console.log(error);
    })
   },

   addTodo() {
      this.nueva = {'tarea':this.nuevaTarea, 'completado':this.nuevoCompletado}
      const path = 'http://localhost:5000/api/todos'
      axios.post(path, this.nueva)
      .then(response =>{
        console.log(response.data)
        this.todos = response.data
        this.nuevaTarea = ''
        this.nuevoCompletado = ''
        this.form = false
        this.boton = true
      })
       .catch(error =>{
        console.log(error);
      })
     },

    updateTodo(index,todo) {
      axios.put(`http://localhost:5000/api/todos/${index}`, { "completado": todo.completado})
      .then(response =>{
        console.log(response.data, this.todos)
        todo.completado = response.data
       })
       .catch(error =>{
        console.log(error);
      })
    },

    deleteTodo(index) {
      axios.delete(`http://localhost:5000/api/todos/${index}`)
        .then(response =>{
          this.todos = response.data
        })
        .catch(error =>{
          console.log(error);
    })
    },

    mostrarForm(){
      this.form = true
      this.boton = false;
    }
  }
};
</script>

<style scoped>

.container {
  background-color: rgba(255, 255, 255, 0.871);
  border-radius: 15px;
  padding: 40px;
  margin: 50px auto;
  width: 90%;
  max-width: 600px; 
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

h1 {
  color: #131313;
  font-weight: 400;
  margin-top: 10px;
}

h2{
  font-weight: 350;
}

#mas{
  background-color: #000000b9;
  border-radius: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  align-self: flex-end;
  font-size: 20px;
  width: 35px;
  height: 35px;
  margin-top: 10px;
}

#mas:hover{
  background-color:#000000ea;
}

table {
  width: 420px;
  margin: 10px;
  display: flex;
  align-items: center;
  justify-content:center;
}

.table th, .table td {
  padding: 5px;
  min-width: auto;
  max-width: auto;
  width: auto;
  text-align: left;
  font-weight: 700;
  text-align: left; 
  min-width: 70px;
  max-width:200px;
  display: flex;
  align-items: center;
  justify-content:flex-start;

}

tr{
  display: flex;
  align-items: left;
  justify-content: left;
  min-height: 65px;
}

.buttonEliminar {
  background-color: #e1343ace;
  padding:10px;
  border: none;
  border-radius: 40px;
  cursor: pointer;
  font-weight: 500;
}

.buttonEliminar:hover {
  background-color: #cb262ce5;
}

.tarea{
  font-weight: 500;
  max-width: 200px;
  min-width:300px;
  padding-left: 15px;
}

.completado{
  gap:10px;
  width:100%;
  text-decoration: line-through 1.5px;
}

input[type="text"] {
  padding: 8px;
  font-size: 16px;
  width:100%;
  border: 1px solid #ddd;
  border-radius: 4px;
}

input[type="checkbox"] {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 35px;
  height: 35px;
  border-radius: 100%;
  border: 2px solid #692682b9;
  cursor: pointer;
  appearance: none; 
  margin-left: 15px;
}

input[type="checkbox"]:checked {
  background-color: #692682b9;
  border-style: none;
  position: relative;
}

input[type="checkbox"]:checked::after {
  content: "";
  position: absolute;
  top: 9px;
  left: 13.5px;
  width: 6px;
  height: 10px;
  border: solid rgb(255, 255, 255);
  border-width: 0 3px 3px 0;
  transform: rotate(45deg);
}

form {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content:center;
  margin-bottom: 32px;
  margin-top: 16px;
  background-color: rgba(255, 255, 255, 0.719);
  padding: 32px;
  border-radius: 8px; 
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

h2{
  margin-bottom: 10px;
}

.contenidoForm {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 16px;
  margin-bottom: 16px;
}

label{
  margin-top: 5px;
}

.checkboxCompletado{
  display:flex;
  align-items: center;
  justify-content: center;
  gap:10px;
  width:100%;
}

button {
  background-color: #000000b9;
  padding:10px;
  color: white;
  border: none;
  border-radius: 30px;
  cursor: pointer;
}

button:hover {
  background-color: #000000ea;
}

@media screen and (max-width: 800px) {
  .container {
    width:80%;
  }
  
}
</style>
