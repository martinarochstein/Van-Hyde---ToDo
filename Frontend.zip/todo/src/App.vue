<script setup>
import TodoList from './components/TodoList.vue';
</script>

<template>
<div id="app">
    <TodoList />
  </div>
</template>

<style scoped>
</style>